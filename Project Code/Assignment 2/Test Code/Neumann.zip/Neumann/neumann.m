% Program to solve a Neumann elliptic problem using slow fourier transform
% and solving system of equations using the Thomas alogorithm

clear

a = 0; b = 1;
c = 0; d = 1;

N = 3;

h = (b-a)/N;

x = a+h:h:b-h;
y = c:h:d;

U = zeros(N+1,N-1);
A = zeros(N+1);
g = zeros(N-1,N+1);

tic
g(1,1) = f(x(1),y(1)) - 0.5*cos(2*pi*y(1))/h^2;
g(1,N+1) = f(x(1),y(N+1)) - 0.5*cos(2*pi*y(N+1))/h^2;
for j=2:N
    g(1,j) = f(x(1),y(j)) - 0.5*cos(2*pi*y(j))/h^2;
end

g(N-1,1) = f(x(N-1),y(1)) - 1/h^2;
g(N-1,N+1) = f(x(N-1),y(N+1)) - 1/h^2;
for j=2:N
    g(N-1,j) = f(x(N-1),y(j)) - 1/h^2;
end

for k=2:N-2
    g(k,1) = (f(x(k),y(1)));
    g(k,N+1) = (f(x(k),y(N+1)));
    for j=2:N
        g(k,j) = (f(x(k),y(j)));
    end 
end

G = h^2*mydst(g);

% k=1:N-1
for k=1:N-1    
    A(1,1) = -(2+4*sin((2*k-1)*pi/(4*N))^2);
    A(1,2) = 2;
    A(N+1,N) = 2;
    A(N+1,N+1) = -(2+4*sin((2*k-1)*pi/(4*N))^2);
    for j=2:N
        A(j,j) = -(2+4*sin((2*k-1)*pi/(4*N))^2);
        A(j,j-1) = 1;
        A(j,j+1) = 1;
    end
    %U(:,k) = thomasSolver(A,G(k,:)');
    U(:,k) = A\G(k,:)';
end

u = myidst(U');
toc

figure(2)
mesh(y,x,u);
title('Approximate solution using Fourier Method (Thomas Algorithm)');
xlabel('x');
ylabel('y');