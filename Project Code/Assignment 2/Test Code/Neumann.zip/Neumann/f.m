function V = f(x,y)
    V = -2*cos(2*pi*x)*cos(2*pi*y);
end