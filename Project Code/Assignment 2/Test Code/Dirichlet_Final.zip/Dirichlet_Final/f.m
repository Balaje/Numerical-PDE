function V = f(x,y)
    V = (x^2+y^2)*exp(x*y);
end